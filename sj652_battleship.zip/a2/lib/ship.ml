(* ship.ml *)

type player_state = Number of int | Empty | Ship
type board = player_state array array
type ship = { size : int }

let battleship_grid size element =
  Array.init size (fun num ->
      Array.init (size + 1) (fun index ->
          if index = 0 then string_of_int (num + 1) else element))

let number_array_top size = Array.init (size + 1) (fun num -> num)

let create_board size =
  Array.init size (fun num ->
      Array.init (size + 1) (fun index ->
          if index = 0 then Number (num + 1) else Empty))

let print_board board =
  Array.iter
    (fun row ->
      Array.iter
        (fun cell ->
          match cell with
          | Empty -> print_string " 🌵"
          | Number num -> print_int num
          | Ship -> print_string " 🐫")
        row;
      print_newline ())
    board

let place_ship board ship =
  let size = Array.length board in
  let row = 1 + Random.int (size - 2) in
  let col = Random.int (size - ship.size) + 1 in
  for i = 0 to ship.size - 1 do
    board.(row).(col + i) <- Ship
  done;
  (row + 1, col)
